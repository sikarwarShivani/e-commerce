import { Routes, BrowserRouter as Router, Route } from "react-router-dom";

import Login from "./administrator/Adminlogin/Login";
import Dashboard from "./administrator/Adminlogin/dashboard";
import Home from './userinterface/screen/Home';
import Hero from './userinterface/components/Hero';


function App() {
  return (
    <div>
      {/* <Home /> */}
      <Router>
        <Routes>
         
          <Route element={<Login />} path="/Login" />
          <Route element={<Dashboard />} path="/dashboard/*" />
          <Route element={<Home />} path="/Home" />
          
        </Routes>
      </Router>


    </div>
  );
}

export default App;
