import { makeStyles } from "@mui/styles";

export const useStyles = makeStyles({


    maincontainer: {
        background: '#dfe4ea',
         width:'100%',
        height:'100vh',
        display:'flex',
        justifyContent: 'center',
        alignItems: 'center'
    },
    box: {
        padding: '1%',
        width: '50%',
        borderRadius:'2%',
        background: '#fff',
        

    }
})