import React, { createRef } from "react";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import ArrowBackIosIcon from '@mui/icons-material/ArrowBackIos';
import ArrowForwardIos from '@mui/icons-material/ArrowForwardIos';
import { KeyboardReturn } from "@mui/icons-material";
import { serverURL } from "../../NodeServices/FetchNodeServices";
// import { useTheme } from '@mui/material/styles';
// import useMediaQuery from '@mui/material/useMediaQuery';
import { Grid } from "@mui/material";


export default function CircleScrollComponent(props) {
    var sliderRef = createRef()
    var color = ['#58B19F', '#D6A2E8', '#F8EFBA', '#CAD3C8', '#ffcccc', '#b8e994', '#ccae62', '#ea8685', '#33d9b2']

    var settings = {
        dots: false,
        infinite: true,
        speed: 500,
        slidesToShow: 6,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 2000,
        arrows: false


    };


    var images = [
        { id: 2, Image: "Dairy & Bakery.png", name: 'Dairy & Bakery' },
        { id: 3, Image: "Fruits & Vegetables.png", name: 'Fruits & Vegetables' },
        { id: 4, Image: "Snacks & Branded Foods.png", name: 'Snacks & Branded Foods' },
        { id: 4, Image: "rice.png", name: 'rice' },
        { id: 5, Image: "Detergents.png", name: 'Detergents' },
        { id: 6, Image: "oil.png", name: 'oil' }
    ]

    const showImages = () => {
        return (
            images.map((item) => {
                return (
                    <div>
                        <div >
                            <div className="box">
                                <div className="box2">
                                    {/* <div style={{ display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center'}}>
                            <div style={{ padding: 2, display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center', width: 160, height: 160, borderRadius: 90, background: color[parseInt(Math.random() * (color.length - 1))] }}> */}
                                    <img src={`${serverURL}/images/${item.Image}`} style={{ width: "80%" }} />
                                    {/* </div>
                            </div> */}
                                </div>
                            </div>
                        </div>
                        <div style={{ display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center', }}>
                            <div style={{ textAlign: 'center', width: '100%' }}>{item.name}</div>
                        </div>
                    </div>)
            })
        )

    }

    const handleBackClick = () => {
        sliderRef.current.slickPrev()
    }

    const handleForwardClick = () => {
        sliderRef.current.slickNext()
    }

    return (
        <div>
            <div style={{ padding: 5, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div style={{ fontFamily: 'Poppins', fontSize: 22, fontWeight: '1800' }}>
                    {props.title}
                </div>
                <div style={{ display: 'flex', flexDirection: 'row', width: '5%', marginBottom: 10 }}>
                    <div >
                        <ArrowBackIosIcon style={{ color: '#000' }} onClick={handleBackClick} />
                    </div>
                    <div className="hero">
                        <ArrowForwardIos style={{ color: '#000' }} onClick={handleForwardClick} />
                    </div>
                </div>-
            </div>
            <Slider {...settings} ref={sliderRef}>
                {/* {showImages()} */}

               { images.map((item) => {
                return (
                <div>
                    <div >
                        <div className="box">
                            <div className="box2">
                                {/* <div style={{ display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center'}}>
                            <div style={{ padding: 2, display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center', width: 160, height: 160, borderRadius: 90, background: color[parseInt(Math.random() * (color.length - 1))] }}> */}
                                <img src={`${serverURL}/images/${item.Image}`} style={{ width: "80%" }} />
                                {/* </div>
                            </div> */}
                            </div>
                        </div>
                    </div>
                    <div style={{ display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center', }}>
                        <div style={{ textAlign: 'center', width: '100%' }}>{item.name}</div>
                    </div>
                </div>)
            })
        }
            </Slider>

        </div>
    );
}
