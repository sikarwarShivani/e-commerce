
// import React, { createRef } from "react";

// export default function CircleScrollComponent(props) {
//     return (
//         <div className="hero"> hi</div>
//     )
// }

