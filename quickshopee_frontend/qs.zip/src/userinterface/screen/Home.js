import { useState, useEffect } from "react";
import Header from '../components/Header';
import BannerComponent from "../components/BannerComponent";
import CircleScrollComponent from "../components/CircleScrollComponent";

export default function Home(props) {


    return (
        <div>
            <Header />
            <div style={{ display: 'flex', marginLeft: '3%', marginTop: '1%', marginRight: '3%', flexDirection: 'column' }} >
                <BannerComponent />
            </div>
            <div style={{ width: "100%", marginTop: '20' }} >
                <CircleScrollComponent title="Popular Categories" />
            </div>
        </div>
    )
}