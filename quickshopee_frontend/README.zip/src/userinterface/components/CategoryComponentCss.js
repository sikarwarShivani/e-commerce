import { makeStyles } from "@mui/styles"
export const useStyles = makeStyles({
    container:{
       display:'grid',
       flexDirection:"column",
        gridColumn:1/5
    }
})