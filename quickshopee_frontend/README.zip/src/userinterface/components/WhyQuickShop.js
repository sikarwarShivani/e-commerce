

export default function WhyQuickShope() {
    return(
        <div>
       <div style={{marginTop:10,
       marginLeft:35,
    color: '#000 rgb(60, 60, 60)',
    fontSize: '18px',
    fontWeight: 500,
    marginBottom: '15px',
      fontFamily:'bold'
}}> Why shop from WhyQuickShop ?</div>

<div style={{display:'flex',marginBottom:'7px'}} > 
    <div style={{width:56, height:56, loading:'lazy',borderRadius:'0px', cursor:'default',marginLeft:35,marginRight:18,marginBottom:'1px',objectFit:'fill'}}>
        <img src="https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=50,metadata=none,w=45/assets/web/blinkit-promises/10_minute_delivery.png" alt="express delivery" ></img> 
        </div>
        <div style={{display:'table-cell',marginLeft:'5px'}}>
          <div  style={{marginLeft:'5px',marginBottom:'1px',color:'#666', fontSize: '12px',}}>Superfast Delivery</div>
            <div style={{marginLeft:'5px',color:'#666', fontSize: '10px',}}>Get your order delivered to your doorstep at the earliest from dark stores near you.</div>
        </div>
</div>


<div style={{display:'flex',marginBottom:'7px'}} > 
    <div style={{width:56, height:56, loading:'lazy',borderRadius:'0px', cursor:'default',marginLeft:35,marginRight:17,marginBottom:'1px',objectFit:'fill'}}>
    <img src="https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=50,metadata=none,w=45/assets/web/blinkit-promises/Best_Prices_Offers.png" alt="best price" ></img>
        </div>
        <div style={{display:'table-cell',marginLeft:'5px'}}>
          <div  style={{marginLeft:'5px',marginBottom:'1px',color:'#666', fontSize: '12px',}}>Best Prices & Offers</div>
            <div style={{marginLeft:'5px',color:'#666', fontSize: '10px',}}>Best price destination with offers directly from the manufacturers.</div>
        </div>
</div>


<div style={{display:'flex',marginBottom:'7px'}} > 
    <div style={{width:56, height:56, loading:'lazy',borderRadius:'0px', cursor:'default',marginLeft:35,marginRight:18,marginBottom:'1px',objectFit:'fill'}}>
    <img src="https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=50,metadata=none,w=45/assets/web/blinkit-promises/Wide_Assortment.png" alt="genuine products" ></img>
        </div>
        <div style={{display:'table-cell',marginLeft:'5px'}}>
          <div  style={{marginLeft:'5px',marginBottom:'1px',color:'#666', fontSize: '12px',}}>Wide Assortment</div>
            <div style={{marginLeft:'5px',color:'#666', fontSize: '10px',}}>Choose from 5000+ products across food, personal care, household & other categories.</div>
        </div>
</div>
</div>
    )
}